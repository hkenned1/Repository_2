# Repository_2
Repository_2
Henry Kennedy, Washington, DC
Career in fintech peer to peer lending
Fascinated with fintech since 2015
